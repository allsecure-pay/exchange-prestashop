<?php

namespace AllsecureExchange\Prestashop\PaymentMethod;

interface PaymentMethodInterface
{

}
