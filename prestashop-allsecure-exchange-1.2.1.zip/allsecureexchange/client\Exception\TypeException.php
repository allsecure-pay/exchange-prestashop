<?php

namespace AllsecureExchange\Client\Exception;

/**
 * Class TypeException
 *
 * @package AllsecureExchange\Client\Exception
 */
class TypeException extends ClientException {

}
