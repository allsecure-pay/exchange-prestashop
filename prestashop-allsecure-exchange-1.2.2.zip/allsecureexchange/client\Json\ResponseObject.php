<?php

namespace AllsecureExchange\Client\Json;

/**
 * Class ResponseObject
 *
 * @package AllsecureExchange\Client\Json
 *
 * @property bool $success
 */
class ResponseObject extends DataObject {

}
