<?php

namespace AllsecureExchange\Prestashop\PaymentMethod;

class CreditCard implements PaymentMethodInterface
{

}
