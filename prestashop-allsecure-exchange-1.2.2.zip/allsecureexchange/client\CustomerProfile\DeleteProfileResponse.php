<?php

namespace AllsecureExchange\Client\CustomerProfile;

use AllsecureExchange\Client\Json\ResponseObject;

/**
 * Class DeleteProfileResponse
 *
 * @package AllsecureExchange\Client\CustomerProfile
 *
 */
class DeleteProfileResponse extends ResponseObject {

}
